/*
GROUP 3 - Sec02
Cory Suzuki - 025749631
Jeannie Gonzalez - 027717857
27 January 2022
Description: This is a Java Program that takes in positive, non alphabetical integers as inputs. It uses the CheckInput class to verify the input is in the desired lower-upper bounded range. All attempts except invalid input are considered as user attempts.

Assignments: Jeannie modified the while loop as the previous logic written by the co-author was in the wrong order. She also hosted the file(s) to be worked on.
Cory edited the syntax of the program into a Java-friendly format and wrote the class method. 
*/
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int upper_bound = 100;     //declaration of random num. bounds.
    int lower_bound = 1;
    int correct_num = (int) (Math.random() * upper_bound) + lower_bound; //generates random numbers
    int user_attempts = 0;
    System.out.println("I'm thinking of a number. Guess a value from 1-100: ");
    int user_input = CheckInput.getIntRange(1,100);
    boolean proceed = true;
      while (proceed) {          //while loop allows user to continue playing until the correct input is given.
        if (correct_num == user_input) {
          user_attempts ++;
          proceed = false;
          System.out.println("Correct! You got it in " + user_attempts + " tries.");
        } else if (correct_num < user_input) {
                user_attempts ++;
                System.out.println("Too high. Guess again: ");
        } else if (correct_num > user_input) {
                user_attempts ++;
                System.out.println("Too low. Guess again: ");
        }
        user_input = CheckInput.getIntRange(1, 100); //checks integer range
      }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    }
}