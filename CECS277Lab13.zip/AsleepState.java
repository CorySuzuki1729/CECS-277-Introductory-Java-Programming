public class AsleepState implements PuppyState {

  @Override
  public String play (Puppy P) {
  return "The Puppy is asleep, it doesn't want to play right now.";
  }

  @Override
  public String feed (Puppy P) {
    System.out.println("The Puppy wakes up and comes running to eat.");
    P.setState(new EatingState());
    P.incFeeds();
    return null;
  }
  
}