class Main {
  public static void main(String[] args) {
    
    System.out.println("Congratulations on your new puppy!");
    Puppy P = new Puppy();

    while (true) {
      System.out.println("What would you like to do?\n1. Feed\n2. Play\n3. Quit");
      int choice = CheckInput.getIntRange(1, 3);
      if (choice == 1) {
        P.giveFood();
      }
      else if (choice == 2) {
        P.throwBall();
      }
      else if (choice == 3) {
        System.out.println("Oh no, your Puppy suddenly died. Maybe you shouldn't be a pet owner...");
        System.exit(0);
      }
    }
  }
  
}

//Note: Hi Jeannie! I got started on the lab, however it is not finished yet. The main needs to be fixed and I am a bit iffy about how the State classes have been written. Will try getting back to the lab.