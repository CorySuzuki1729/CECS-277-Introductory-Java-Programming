public interface PuppyState {

  public String play (Puppy P);

  public String feed (Puppy P);
  
}