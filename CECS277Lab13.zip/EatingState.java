public class EatingState implements PuppyState{

  @Override
  public String play(Puppy P){
    System.out.println("The Puppy looks up from its food and chases the ball you threw.");
    P.setState(new PlayState());
    P.incPlays();
    return null;
  }
  
  @Override
  public String feed(Puppy P){
    System.out.println("The Puppy continues to eat as you add another scoop of kibble to its bowl.");
    int numFeed = P.incFeeds();
    if (numFeed > 2){
      System.out.println("The Puppy ate so much it fell asleep!");
      P.reset();
      P.setState(new AsleepState());
    }
    return null;
  }
  
}