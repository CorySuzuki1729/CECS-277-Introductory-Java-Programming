/*
GROUP 3 - Sec 02
Cory Suzuki - 025749631
Jeannie Gonzalez - 027717857
3 February 2022
Description:
This program runs a rock-paper-scissors game which can be played between the computer and a user. The user inputs an
 integer from 1-3 and the computer does so as well, with rock=1, paper=2, scissors=3.
Assignments: Jeannie wrote the getWeapon(), main(), and displayScore(). She also implemented the checkinput() file.
 Cory wrote the getMenuChoice(), getComputerChoice(), and compareThrows(). Both authors contributed to
  syntax reformatting and Java Documentation.
*/

class Main {
  /**
   * This is the main method that contains each of the score variables and choices for
   * the player and the computer respectively.
   * @param args No parameters as arguments taken into the main method.
   */
  public static void main(String[] args){
    int playerScore = 0;
    int compScore = 0;
    int playerChoice = 0;
    int compChoice = 0;
    int start = 0;            //This variable contains the getMenuChoice() method to run the main menu.
    int dub = 0;

    while(true){                  //while loop uses Boolean values to start, continue, and exit the program.
      start = getMenuChoice();

      if (start == 1){
        playerChoice = getWeaponChoice();
        compChoice = getComputerChoice();
        dub = compareThrows(playerChoice, compChoice);
        if (dub ==1){
          playerScore ++;       //Player and computer scores are kept in totals by a variable holding compareThrows().
        }
        else if (dub == 2){
          compScore ++;
        }
      }
      else if (start == 2){
        System.out.println("\n");
        displayScore(playerScore, compScore);
      }
      else{
        System.out.println("\nFinal Score: ");
        displayScore(playerScore, compScore);
        System.exit(0);
      }
    }
  }

  /**
   * This method prints the main menu of the program and checks user input through the CheckInput file.
   * @return The user's inputted option represented as an integer value.
   */
  public static int getMenuChoice(){
    System.out.println("\nRoshambo: ");
    System.out.println("1. Play game");
    System.out.println("2. Show score");
    System.out.println("3. Quit");
    return CheckInput.getInt();
  }

  /**
   * This method allows the user to enter an integer (1-3) to choose their weapon of choice.
   * @return The user's weapon choice represented as an integer.
   */
  public static int getWeaponChoice(){
    System.out.println("\nWhich do you choose?");
    System.out.println("1. Rock");
    System.out.println("2. Paper");
    System.out.println("3. Scissors");
    return CheckInput.getInt();
  }

  /**
   * This method uses the math class's random method to generate the computer's weapon choice.
   * @return The computer's weapon choice as an integer (from 1-3).
   */
  public static int getComputerChoice() {
    int compChoice = (int) (Math.random() * 3) + 1;  //1 is represented as the lower bound, 3 as the upper bound.
    return compChoice;
  }

  /**
   * This method uses the user's choice and computer's choice and determines the winner of each round.
   * @param player This parameter is called in from main method and uses the returned user input.
   * @param comp This parameter is called in from the main method and uses the returned computer input.
   * @return The winner is returned as an integer value to be used by the main method for keeping score.
   */
  public static int compareThrows(int player, int comp) {
    int dub = 0;
    String outcome = "";
    String playerChoice = "";
    String compChoice = "";

    if (player == 1){
      playerChoice += "Rock";
    }
    else if (player == 2){
      playerChoice += "Paper";
    }
    else if (player == 3){
      playerChoice += "Scissors";
    }

    if (comp == 1){
      compChoice += "Rock";
    }
    else if (comp == 2){
      compChoice += "Paper";
    }
    else if (comp == 3){
      compChoice += "Scissors";
    }
    System.out.printf("\nYou chose %s \n", playerChoice);
    System.out.printf("Computer chose %s \n", compChoice);

    if (player == 1 && comp == 3 || player == 3 && comp == 1){  //The || denotes the "or" operator, and && denotes "and".
      System.out.println("Rock crushes Scissors");
    }
    else if (player == 2 && comp == 1 || player == 1 && comp == 2){
      System.out.println("Paper covers Rock");
    }
    else if (player == 3 && comp == 2 || player == 2 && comp == 3){
      System.out.println("Scisscors cuts Paper");
    }

    if (player == 1 && comp == 3 || player == 2 && comp == 1 || player == 3 && comp == 2){
      System.out.println("Player wins");
      dub = 1;
    }
    else if (player == 3 && comp == 1 || player == 1 && comp == 2 || player == 2 && comp == 3){
      System.out.println("Computer wins");
      dub = 2;
    }
    else{
      System.out.println("Tie");
    }
    return dub;
  }

  /**
   * This method displays the user's and computer's score onto the console when the option is selected.
   * @param playerScore This parameter is called from the main method which contains the running score of the user.
   * @param compScore This parameter is called from the main method which contains the running score of the computer.
   */
  public static void displayScore(int playerScore, int compScore) {
    System.out.printf("Player = %d\n", playerScore);
    System.out.printf("Computer = %d\n", compScore);
  }
}