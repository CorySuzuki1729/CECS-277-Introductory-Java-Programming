import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
class Main {
  public static void main(String[] args) {
    DecimalFormat df1 = new DecimalFormat("##.#");
    boolean reg = true;    //Controls the while loop
    while (reg) {int selection;
    ArrayList <Integer> kirby;  //Temp variable for our arraylist
    selection = getMenuInput();
    kirby = readFile();
    if (selection == 1){  //Option 1 prints the grades
    System.out.println("List of all grades: ");
    displayGrades(kirby);
    System.out.println();
    reg = true;   //While loop continues
    }
    else if (selection == 2){  //Option 2 sums the grades and returns the mean
      float summation = sumGrades(kirby);
      System.out.println("The Average is: " + df1.format(summation));
      sumGrades(kirby);
      System.out.println();
      reg = true;
    }
    else if (selection == 3){  //Option 3 finds the maximum/supremum of the arraylist
      int max_val = Collections.max(kirby);
      System.out.println("The Maximum Grade is: " + max_val);
      reg = true;
    }
    else if (selection == 4){  //Option 4 finds the minimum/infimum of the arraylist
      int min_val = Collections.min(kirby);
      System.out.println("The Minimum Grade is: " + min_val);
      reg = true;
    }
    else if (selection == 5){  //Option 5 finds the median
      float real_median = findMedian(kirby);
      System.out.print("The Median Grade is: " + real_median);
      findMedian(kirby);
      System.out.println();
      reg = true;
    }
    else if (selection == 6){  //Option 6 finds the mode
      ArrayList <Integer> real_mode = findMode(kirby);
      System.out.print("Mode: " + real_mode.toString().replace("[", "").replace("]", "").replace(",", " "));
      findMode(kirby);
      System.out.println();
      reg = true;
    }
    else if (selection == 7){  //Option 7 ends the program
      reg = false;
      System.exit(0);
      }
    }
  }
  public static ArrayList<Integer> readFile(){  //Method creates Arraylist
    ArrayList <Integer> grade_book = new ArrayList <Integer> ();
     
    try {   //try block declares new file reader and adds its contents to the arraylist
      Scanner read = new Scanner( new File("grades.txt"));
      while (read.hasNextInt()) { //while loop reads every item
        int nums = read.nextInt();
        grade_book.add(nums);
      }
      read.close();
    }
    catch (FileNotFoundException fnf) {  //Required fnf exception
      System.out.println("File was not found.");
    }
    Collections.sort(grade_book);
    return grade_book;  //return modified ArrayList
  }

  public static void displayGrades(ArrayList<Integer> grade_list){
    int i = 0;
    for (int grade : grade_list){
      if (i == 10){  //Displays grades in rows of 10 elements
        System.out.println();
        i = 0;
      }
      System.out.printf("%-3d", grade);
      i++;
    }
    System.out.println();
  }

  
  public static float sumGrades(ArrayList<Integer> grade_list){
    float i = 0;
    float average = 0;  //sums the arraylist and finds the average
    for (int grade : grade_list){
      i += grade;
      average = ( i / grade_list.size());
      
    }
    return average; 
  }

  public static float findMedian(ArrayList<Integer> grade_list){
    float median = 0;
    int index = grade_list.size() / 2;
    if (grade_list.size() % 2 == 0){
      median = ((float)grade_list.get(index-1) + grade_list.get(index)) / 2;  //averages two medians for a true median
    }
    else{
      median = grade_list.get(index);
    }
    return median;
  }

  public static ArrayList<Integer> findMode(ArrayList<Integer> grade_list){
    ArrayList<Integer> mode = new ArrayList<Integer>();
    int find_mode = 0;
    for (int grade : grade_list){
      int gradeFreq = Collections.frequency(grade_list, grade);
      if (gradeFreq > find_mode){
        mode.clear();
        mode.add(grade);
        find_mode = gradeFreq;
      }
      else if(gradeFreq == find_mode && !mode.contains(grade)){
        mode.add(grade);
      }
    }
    return mode;
  }

  public static int getMenuInput(){   //return user's input
    Scanner loadit = new Scanner(System.in);
    System.out.println("****************************");
    System.out.println("1. Display Sorted Grades");
    System.out.println("2. Display Average Grade");
    System.out.println("3. Display Maximum Grade");
    System.out.println("4. Display Minimum Grade");
    System.out.println("5. Display Median Grade");
    System.out.println("6. Display Mode");
    System.out.println("7. Quit");
    System.out.println("Selection: ");
    int choice = CheckInput.getIntRange(1,7);  //Validates user input
    return choice;
  }
}  