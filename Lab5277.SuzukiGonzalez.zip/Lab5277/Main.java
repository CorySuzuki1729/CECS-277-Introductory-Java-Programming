/**
 * Group 3 - Sec. 2
 * Cory Suzuki-025749631
 * Jeannie Gonzalez-027717857
 * 24 February 2022
 * Description: This is a Java program that acts as the main class that executes a program
 * that translates a rectangle on the Cartesian (xy plane) in the space R^2. The plane is limited
 * to a 20 by 20 two dimensional array.
 *
 * Assignments: Cory wrote the Rect.java class that corresponds with this exercise and wrote the
 * code for displaying the menu and wrote the code for resetting the grid. Jeannie wrote the code
 * for the method of placing the rectangle and main. Both authors equally contributed to code
 * review and edited each other's code segments.
 */
class Main {
  public static void main(String[] args) {
    int rows = 20;
    int cols = 20;
    boolean regulator = true;
    String [][] cartesian = new String[rows][cols];  //Initialize the 2D array.
    for (int i = 0; i < cartesian.length; i++) {
      for (int j = 0; j < cartesian[0].length; j++) {
        cartesian[i][j] = " . ";
      }
    }
      System.out.println("Enter rectangle width (1-5)? ");  //Prompt the user to enter width
      int rectangle_width = CheckInput.getIntRange(1, 5);   //and height of the rectangle.
      System.out.println("Enter rectangle height (1-5)? ");
      int rectangle_height = CheckInput.getIntRange(1, 5);
      Rect rectangle = new Rect(rectangle_width, rectangle_height);  //Initialize new rectangle.
      placeRect(cartesian, rectangle);
      displayGrid(cartesian);
      int user_select = menu();
      while (regulator) {  //while loop specifically designed to loop the menu for translation.
      if (user_select == 1) {
        if (rectangle.getY() != 0) {
        rectangle.translate(0,-1);  //Translate the rectangle downwards.
        resetGrid(cartesian);
        placeRect(cartesian, rectangle);
        displayGrid(cartesian);
        user_select = menu();
        }
        else {
          System.out.println("You cannot go that way.");  //Lower boundary created.
          user_select = CheckInput.getIntRange(1,5);
        }
      }
      else if (user_select == 2) {
        if (rectangle.getY() != 20 - rectangle.getHeight()) {
        rectangle.translate(0,1);  //Translate the rectangle upwards.
        resetGrid(cartesian);
        placeRect(cartesian, rectangle);
        displayGrid(cartesian);
        user_select = menu();
        }
        else{
          System.out.println("You cannot go that way.");  //Upper boundary created.
          user_select = CheckInput.getIntRange(1,5);
        }
      }
      else if (user_select == 3) {
        if (rectangle.getX() != 0){
        rectangle.translate(-1,0);  //Shift the rectangle to the left.
        resetGrid(cartesian);
        placeRect(cartesian, rectangle);
        displayGrid(cartesian);
        user_select = menu();
        }
        else{
          System.out.println("You cannot go that way.");  //Left boundary created.
          user_select = CheckInput.getIntRange(1,5);
        }  
      }
      else if (user_select == 4) {
        if (rectangle.getX() != 20 - rectangle.getWidth()){
        rectangle.translate(1,0);  //Shift rectangle to the right.
        resetGrid(cartesian);
        placeRect(cartesian, rectangle);
        displayGrid(cartesian);
        user_select = menu();
        }
        else{
          System.out.println("You cannot go that way.");  //Right boundary created.
          user_select = CheckInput.getIntRange(1,5);
        }
      }
      else if (user_select == 5) {
        regulator = false;
        System.out.println("Quitting...");
        System.exit(0);
      }
    }
  }

  /**
   * This method displays the 2D array at its present state whether filled or unfilled.
   * @param grid This is the 2D array.
   */

  public static void displayGrid(String [][] grid) {
    for (int i = 0; i <grid.length; i++) {
      for (int j = 0; j < grid[0].length; j++) {
        System.out.print( grid[i][j] );  //Print present 2D array.
      } 
      System.out.println();
    }
  }

  /**
   * This method places the rectangle onto the 2D array based on the given specifics of its width
   * and height.
   * @param grid This is the 2D array to be modified with aterisks.
   * @param rectangle This is the rectangle object from the Rect.java class.
   * @return This is the newly modified 2D array with the rectangle drawn.
   */

  public static String [][] placeRect(String [][] grid, Rect rectangle) { 
    for (int i = rectangle.getY(); i < rectangle.getY() + rectangle.getHeight(); i++){
      for (int j = rectangle.getX(); j < rectangle.getX() + rectangle.getWidth(); j++){
        grid[i][j] = " * ";  //Using width and height, create rectangle on the plane.
      }
    }
    return grid;
  }

  /**
   * This method resets the 2D array to its former formation with periods.
   * @param grid This is the cartesian plane grid to be modified.
   */

  public static void resetGrid(String [][] grid) {
    for (int i = 0; i < grid.length; i++) {
      for (int j = 0; j < grid[0].length; j++) {
        grid[i][j] = " . ";  //Reset array to default formatting.
      }
    }
  }

  /**
   * This method displays the translation menu to the user and prompts an integer decision
   * between 1 to 5. 5 will end the program.
   * @return The user's choice to be used in the main method that runs this class.
   */

  public static int menu() {
    System.out.println("Enter direction: ");
    System.out.println("1. Up");
    System.out.println("2. Down");
    System.out.println("3. Left");
    System.out.println("4. Right");
    System.out.println("5. Quit");
    int user_choice = CheckInput.getIntRange(1,5);
    return user_choice;  //Return the user's choice.
    }
}