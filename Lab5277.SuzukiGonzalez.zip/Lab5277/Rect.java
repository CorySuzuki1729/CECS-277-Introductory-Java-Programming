/**
 * Group 3 - Sec. 2
 * Cory Suzuki-025749631
 * Jeannie Gonzalez-027717857
 * 24 February 2022
 * Description: This is a Java program that acts as the Rectangle class that executes a program
 * that holds instances of the rectangle object used in the main class. Each method holds the x
 * coordinate, y coordinate, width, and height of the rectangle and performs the translation.
 *
 * Assignments: Cory wrote the Rect.java class that corresponds with this exercise and wrote the
 * code for displaying the menu and wrote the code for resetting the grid. Jeannie wrote the code
 * for the method of placing the rectangle and main. Both authors equally contributed to code
 * review and edited each other's code segments.
 */

public class Rect {
  private int x;  //Initialize instance variables of the class.
  private int y;
  private int width;
  private int height;


  public Rect(int w, int h) {
    this.width = w;
    this.height = h;
    this.x = 0;  //Set (0,0) as the origin of the xy plane.
    this.y = 0;
  }

  /**
   * This method returns the x coordinate of the rectangle.
   * @return The x coordinate of the rectangle object.
   */

  public int getX() {
    return this.x;
  }

  /**
   * This method returns the y coordinate of the rectangle.
   * @return The y coordinate of the rectangle object.
   */

  public int getY() {
    return this.y;
  }

  /**
   * This method returns the width of the rectangle.
   * @return The width of the rectangle.
   */

  public int getWidth() {
    return this.width;
  }

  /**
   * This method returns the height of the rectangle.
   * @return The height of the rectangle object.
   */

  public int getHeight() {
    return this.height;
  }

  /**
   * This method translates the rectangle object on the xy plane.
   * @param dx This is the specified change in x in a unit.
   * @param dy This is the specified change in y in a unit.
   */

  public void translate(int dx, int dy) {
    x += dx;  //the x coordinate is incremented by dx, the change in x.
    y += dy;  //the y coordinate is incremented by dy, the change in y.
    }
}