/**
 * This is the MonsterDecorator class which is a decorator class that extends the
 * abstract monster class. It incorporates the monster object, its name, and its
 * health points and is used as a template for monster components to be created.
 * The monster's attack method which is defined abstractly in Monster is returned
 * here.
 */


abstract class MonsterDecorator extends Monster {
  private Monster monster;

  public MonsterDecorator(Monster m, String addname, int addHp) {
    super(addname, addHp);
    monster = m;
  }

  public int attack() {
    return monster.attack();
  }
}