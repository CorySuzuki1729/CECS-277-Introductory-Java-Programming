/**
 * This is the Lasers class which extends the abstract MonsterDecorator class. It uses
 * a super constructor that passes in the Monster abstractly and adds a String adjective
 * to describe the laser ability being applied to the monster. This class also
 * increases the hp of the monster by 5.
 */


public class Lasers extends MonsterDecorator{

  public Lasers(Monster m){
    super(m, m.getName() + " with Laser Beams", m.getHp() + 5);
  }

  public int attack(){
    final int LASER_DAMAGE = 7;
    return super.attack() + LASER_DAMAGE;
  }
}