/**
 * This is the Poison class which extends the abstract MonsterDecorator class. It uses
 * a super constructor that passes in the Monster abstractly and adds a String adjective
 * to describe the poisonous ability being applied to the monster. This class also
 * increases the hp of the monster by 4.
 */

public class Poison extends MonsterDecorator {
  public Poison(Monster m) {
    super(m, "Poisonous " + m.getName(), m.getHp() + 4);
  }

  @Override
  public int attack() {
    final int POISON_DAMAGE = 3;
    return super.attack() + POISON_DAMAGE;
  }
}