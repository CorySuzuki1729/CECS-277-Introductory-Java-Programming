/**
 * This is the fire class which extends the abstract MonsterDecorator class. It uses
 * a super constructor that passes in the Monster abstractly and adds a String adjective
 * to describe the fire ability being applied to the monster. This class also
 * increases the hp of the monster by 2.
 */


public class Fire extends MonsterDecorator{

  public Fire(Monster m){
    super(m, "Firey " + m.getName(), m.getHp() + 2);
  }

  public int attack(){
    final int FIRE_DAMAGE = 5;
    return super.attack() + FIRE_DAMAGE;
  }
  
}