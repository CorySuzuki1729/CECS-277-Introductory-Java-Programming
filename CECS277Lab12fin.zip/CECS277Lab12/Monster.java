/**
 * This is the Monster abstract class which creates a Monster object that has attributes
 * such as a string name and integer health points. The monster's name, health, and
 * attack information is stored abstractly into the object.
 */

abstract class Monster {
  private int hp;
  private String name;

  public Monster (String n, int h) {
    name = n;
    hp = h;
  }
  
  public String getName() {
    return name;
  }

  public int getHp() {
    return hp;
  }

  public abstract int attack();  //declare attack as an abstract method.
}