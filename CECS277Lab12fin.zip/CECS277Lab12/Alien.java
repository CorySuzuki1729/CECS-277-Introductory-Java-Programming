/**
 * This is the Alien class which extends the abstract class Monster. The super constructor
 * uses a dummy string and integer data type to be changed to the type of monster which is being
 * requested by the user. This class also overrides the attack damage for the Alien monster
 * specifically.
 */


public class Alien extends Monster {
  public Alien() {
    super("Alien", 20);
  }
  
  @Override
  public int attack() {
    int alien_att = (int)(Math.random() * 4) + 1;
    return alien_att;
  }
}