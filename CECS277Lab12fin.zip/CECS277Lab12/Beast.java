/**
 * This is the Beast class which extends the abstract class Monster. The super constructor
 * uses a dummy string and integer data type to be changed to the type of monster which is being
 * requested by the user. This class also overrides the attack damage for the Beast monster
 * specifically.
 */


public class Beast extends Monster {
  public Beast() {
    super("Beast", 15);
  }

  @Override
  public int attack() {
    int beast_att = (int)(Math.random() * 5) + 1;
    return beast_att;
  }
}