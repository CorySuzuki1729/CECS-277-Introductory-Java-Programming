/**
 * Lab 12
 * Group 3 - Sec. 02
 * Cory Suzuki - 025749631
 * Jeannie Gonzalez - 027717857
 * 28 April 2022
 *
 * Description: This is a program that runs a basic monster creation game which uses the
 * decorator pattern. It is designed to let the user start with a monster base (either
 * alien, beast, or undead), and add an unlimited amount of abilities such as fire, poison,
 * or lasers. This program runs until the user quits with option 4.
 *
 * Assignments: Cory was tasked with writing the base classes, the Monster class, and the Monster
 * decorator. Jeannie was tasked with writing the Main class and the Monster decorator classes
 * (the ability classes). Jeannie also performed debugging and testing while Cory wrote the
 * Javadocs.
 */

/**
 * The main class is the backbone of the program by displaying the monster creator menus
 * and prompting input from the user. It uses a while loop when the user hasn't pressed the
 * quitting option to continue the program until that condition is met.
 */
class Main {
  public static void main(String[] args) {

    int menuInput = 0;
    int menuInput2 = 0;
    
    System.out.println("Monster Creator!");
    System.out.println("Choose a base monster: ");
    System.out.println("1. Alien");
    System.out.println("2. Beast");
    System.out.println("3. Zombie");
    menuInput = CheckInput.getIntRange(1, 3);  //check the inputs.

    Monster m = new Alien();

    if(menuInput == 1){
      m = new Alien();
    }
    else if(menuInput == 2){
      m = new Beast();
    }
    else if(menuInput == 3){
      m = new Undead();
    }

    menuInput2 = 0;
    while(menuInput2 != 4){
      System.out.println(m.getName() + " has " + m.getHp() + " hp " + "and attacks for " + m.attack() + " damage.");
      System.out.println("Add an ability: \n1. Fire \n2. Lasers \n3. Poison \n4. Quit");
      menuInput2 = CheckInput.getIntRange(1, 4);
      if (menuInput2 == 1){
        m = new Fire(m);
      }
      else if (menuInput2 == 2){
        m = new Lasers(m);
      }
      else if (menuInput2 == 3){
        m = new Poison(m);
      }
      else if(menuInput2 == 4){
        System.out.println("Exiting");   //Loop condition met, exit the program.
      }
    }
  }
}