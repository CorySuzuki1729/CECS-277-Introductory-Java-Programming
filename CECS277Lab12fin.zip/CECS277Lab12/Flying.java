/**
 * This is the Flying class which extends the abstract MonsterDecorator class. It uses
 * a super constructor that passes in the Monster abstractly and adds a String adjective
 * to describe the flight ability being applied to the monster. This class also
 * increases the hp of the monster by 4.
 */


public class Flying extends MonsterDecorator{

  public Flying(Monster m){
    super(m, "Flying " + m.getName(), m.getHp() + 4);
  }

  public int attack(){
    return 1;
  }
}