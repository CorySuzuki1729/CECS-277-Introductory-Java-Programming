/**
 * This is the Undead class which extends the abstract class Monster. The super constructor
 * uses a dummy string and integer data type to be changed to the type of monster which is being
 * requested by the user. This class also overrides the attack damage for the Undead monster
 * specifically.
 */


public class Undead extends Monster {
  public Undead() {
    super("Zombie", 25);
  }

  @Override
  public int attack() {
    int undead_att = (int)(Math.random() * 3) + 1;
    return undead_att;
  }
}